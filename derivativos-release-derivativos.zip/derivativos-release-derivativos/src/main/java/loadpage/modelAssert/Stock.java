package loadpage.modelAssert;

import com.google.gson.annotations.SerializedName;

public class Stock {

	// "id": 133,
	@SerializedName("id")
	private String id;

	// "symbol": "STBP3",
	@SerializedName("symbol")
	private String symbol;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

}
