package loadpage.modelAssert;

import com.google.gson.annotations.SerializedName;

public class Autentication {
	
	
	//"access-token": "CKT3oIbF2I+FTlqpqWN3eS3m2xCVNjOAWLgmMoA52WDOupCWriW1868VHzIzLMECZiOpdMNfyk6mKhqliorsag==--bCnF4Copwvc843FH2eKrkw==--tXbFWxjFrIrz2huNdzeY3g==",
	@SerializedName("access-token")
	private String access_token;
	
	
	private boolean logado;

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public boolean isLogado() {
		return logado;
	}

	public void setLogado(boolean logado) {
		this.logado = logado;
	}
	
	
	
	
	
	
	

}
