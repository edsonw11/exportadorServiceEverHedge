package loadpage.modelAssert;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;

import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import loadpage.LoadPage;

public class Login extends JFrame {

	private JTextField emailLogin;
	private JPasswordField senhaLogin;
	private JButton btnLogin, btnLimpa;
	private JLabel lblEmail, lblPassword;

	public static Autentication objAutentication = new Autentication();

	static int numeroDeExtrategias = 0;

	public Login() {

		super("Exportar Operacoes");

		setLayout(new FlowLayout(FlowLayout.LEFT));

		lblEmail = new JLabel("Email: ");
		add(lblEmail);

		emailLogin = new JTextField(15);
		add(emailLogin);

		lblPassword = new JLabel("Senha:   ");
		add(lblPassword);

		senhaLogin = new JPasswordField(15);
		add(senhaLogin);

		btnLogin = new JButton("Entrar");

		// lblProcess= new JLabel("status: ");
		// lblProcess.show(true);

		// add(lblProcess);

		btnLogin.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent evento) {

				try {
					// lblProcess.setText("Processando...");

					Autentication objAutentication = doAuthentication(emailLogin.getText(), senhaLogin.getText());

					if (objAutentication.isLogado()) {
						//createWorkbook(doGetAssertOPAbertas(LoadPage.posicoesAbertas, Login.objAutentication));
						createWorkbook(doGetAssertOPAbertas(LoadPage.posicoesAbertas, Login.objAutentication));
					} else {
						JOptionPane.showConfirmDialog(null, " Erro de Login, tente novamete!", "",
								JOptionPane.WARNING_MESSAGE);
						
					}

				} catch (UnirestException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				emailLogin.grabFocus();

			}
		});
		add(btnLogin);

		btnLimpa = new JButton("Limpar");
		btnLimpa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evento) {
				if (evento.getSource() == btnLimpa) {
					emailLogin.setText("");
					senhaLogin.setText("");
					emailLogin.grabFocus();
					
				}
			}
		});
		add(btnLimpa);
	}

	private static Autentication doAuthentication(String email, String password) throws UnirestException {

//			HttpResponse<String> response = Unirest.post("https://api.oplab.com.br/v2/users/authenticate")
//					  .header("content-type", "application/json")
//					  .header("cache-control", "no-cache")
//					  .header("postman-token", "e32e67f8-f492-32e2-6fb1-256bd9a6bbec")
//					  .body("{\n\t   \"postId\": 101, \n       \"email\": \"edsonw11@gmail.com\",\n       \"password\": \"tech2081\" }")
//					  .asString();

		HttpResponse<String> response = Unirest.post("https://api.oplab.com.br/v2/users/authenticate")
				.header("content-type", "application/json").header("cache-control", "no-cache")
				.header("postman-token", "e32e67f8-f492-32e2-6fb1-256bd9a6bbec")
				.body("{\n\t   \"postId\": 101, \n       \"email\": \"" + email + "\",\n       \"password\": \""
						+ password + "\" }")
				.asString();

		//System.out.println(response.getBody());

		// Autentication objAutentication = new
		// Gson().fromJson(response.getBody().trim(), Autentication.class);
		try {
			objAutentication = new Gson().fromJson(response.getBody().trim(), Autentication.class);

			if (objAutentication != null && objAutentication.getAccess_token().length() > 0) {
				objAutentication.setLogado(true);
			} else {
				objAutentication = new Autentication();

				objAutentication.setLogado(false);
				objAutentication.setAccess_token("erro login");
			}

		} catch (Exception e) {
			objAutentication = new Autentication();

			objAutentication.setLogado(false);
			objAutentication.setAccess_token("erro login");

		}

		// System.out.println(objAutentication);

		return objAutentication;
	}

	public static List<OpAberta> doGetAssertOPAbertas(String objFind, Autentication autentication)
			throws UnirestException {

		HttpResponse<String> response = Unirest.get(objFind).header("access-control-allow-headers",
				"DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range,Access-Token,Authorization")
				.header("authorization", "Basic ZWRzc29udzExQGdtYWlsLmNvbTp0ZWNoMjA4MQ==")
				.header("access-token", autentication.getAccess_token())
				// .header("access-token",
				// "O62AjLdEI/aYU450Y2z7pPJmNBpap7wqe9KCKoNz3dLTHFz8o7q917MqlYfAJl3LtPHuSutvC4wTwgnDBBl/SQ==--HN/OWBlOW9kK1IKXM+Dw8g==--6Pbbam5VueoWsrgRKkyTmQ==")
				// .header("email", email)
				// .header("password", password)
				.header("cache-control", "no-cache").header("postman-token", "9f127d97-6815-3fe9-e4d2-eff406e5e17c")
				.asString();

		return doBuilDopAberta(response);

	}

	private static List<OpAberta> doBuilDopAberta(HttpResponse<String> response) {

		OpAberta[] obj = new Gson().fromJson(response.getBody(), OpAberta[].class);

		List<OpAberta> listaOperacoesAbertas = new ArrayList<OpAberta>();

		for (OpAberta obA : obj) {
			// ArrayList<OpAberta> legAberta = new ArrayList<OpAberta>();
			Iterator iterator = ((Map) obA.getLegsAbertas()).entrySet().iterator();

			LegAberta[] legAberta = null;

			while (iterator.hasNext()) {
				Map.Entry entry = (Map.Entry) iterator.next();

				if (entry.getKey().equals("in")) {

//	    		        	System.out.print( "%%%%% In %%%%% \n" );
//	        		        System.out.print(entry.getValue() +  "%%%%% \n" );
//	        		        System.out.print( "%%%%% In %%%%% \n" );

					legAberta = new Gson().fromJson(
							entry.getValue().toString().trim().replaceAll("maturity-type=}", "maturity-type=papel}"),
							LegAberta[].class);

					// listaOperacoesAbertas.get(0).getListLegs().add(null)

				}

			}

			//System.out.println("+++++++ Operacao Aberta ++++++++++ \n");
			//System.out.println(obA.getName());

			for (LegAberta leg : legAberta) {
				System.out.print("Opcao : " + leg.getSymbol());
				obA.getListLegs().add(leg);
			}

			listaOperacoesAbertas.add(obA);

		}

		return listaOperacoesAbertas;
	}

	public static void createWorkbook(List<OpAberta> opAbertas) throws IOException {

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Operacoes");

		sheet.setDefaultColumnWidth(15);
		sheet.setDefaultRowHeight((short) 400);

		int rownum = 0;
		int cellnum = 1;
		Cell cell;
		Row row;

		// Configurando estilos de células (Cores, alinhamento, formatação, etc..)
		HSSFDataFormat numberFormat = workbook.createDataFormat();

		CellStyle headerStyle = workbook.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
		headerStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		CellStyle textStyle = workbook.createCellStyle();
		textStyle.setAlignment(CellStyle.ALIGN_LEFT);
		textStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		
		
		CellStyle textStyleNomeEstrategia = workbook.createCellStyle();
		textStyleNomeEstrategia.setAlignment(CellStyle.ALIGN_LEFT);
		textStyleNomeEstrategia.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		textStyleNomeEstrategia.setFillPattern(CellStyle.SOLID_FOREGROUND);
		textStyleNomeEstrategia.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
		
		CellStyle textStyleBuy = workbook.createCellStyle();
		textStyleBuy.setAlignment(CellStyle.ALIGN_LEFT);
		textStyleBuy.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		textStyleBuy.setFillPattern(CellStyle.SOLID_FOREGROUND);
		textStyleBuy.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
		
		CellStyle textStyleSELL = workbook.createCellStyle();
		textStyleSELL.setAlignment(CellStyle.ALIGN_LEFT);
		textStyleSELL.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		textStyleSELL.setFillPattern(CellStyle.SOLID_FOREGROUND);
		textStyleSELL.setFillForegroundColor(IndexedColors.ROSE.getIndex());
		

		

		CellStyle numberStyle = workbook.createCellStyle();

		numberStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		// Configurando Header
		row = sheet.createRow(rownum++);
		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Nome estrategia");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Symbol");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Action");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Strike");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("PrecoCompra");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Amount");

		// Adicionando os dados dos produtos na planilha
		for (OpAberta op : opAbertas) {

			row = sheet.createRow(rownum++);
			cellnum = 1;

			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyleNomeEstrategia);
			cell.setCellValue(op.getName());
			
			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyleNomeEstrategia);
			
			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyleNomeEstrategia);
			
			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyleNomeEstrategia);
			
			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyleNomeEstrategia);
			
			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyleNomeEstrategia);
			
			numeroDeExtrategias++;

			for (LegAberta leg : op.getListLegs()) {
				
				if(leg.getAction().equals("BUY")) {
					textStyle = textStyleBuy;

				}else {
					textStyle = textStyleSELL;
					
				}
			

				row = sheet.createRow(rownum++);
				cellnum = 2;

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getSymbol());

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getAction());

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getStrike());

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getPrice_in());

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getAmount());
			}
			
			row = sheet.createRow(rownum++);
			


		}

		try {
			
			
			

			JFileChooser fc = new JFileChooser();

			int returnVal = fc.showSaveDialog(new JFrame());
			
			if (returnVal == JFileChooser.CANCEL_OPTION) {
				return;
			}
			fc.setDialogTitle("Escolha um diretorio para salvar");

			String pathToSave = fc.getSelectedFile() + ".xls";
			// Escrevendo o arquivo em disco
			FileOutputStream out = new FileOutputStream(pathToSave);

			JOptionPane.showConfirmDialog(null, numeroDeExtrategias + " estrategias exportada com com Sucesso!! \n Arquivo Salvo no diretorio : " + pathToSave, "",
					JOptionPane.WARNING_MESSAGE);

			System.out.println("Success!!");

			numeroDeExtrategias = 0;

			workbook.write(out);
			out.close();
			workbook.close();
			System.exit(0);
			
		

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
