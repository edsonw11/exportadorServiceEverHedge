package loadpage.modelAssert;

import com.google.gson.annotations.SerializedName;

public class SerieAvailable {

	// "id": 1005,
	@SerializedName("id")
	private String id;

	// "name": "STBPK",
	@SerializedName("name")
	private String name;

	// "due-date": "2021-11-19",
	@SerializedName("due-date")
	private String dueDate;

	// "block-date": "2021-11-19",
	@SerializedName("block-date")
	private String blockDate;

	// "days-to-maturity": 22,
	@SerializedName("days-to-maturity")
	private String daysToMaturity;

	// "type": "CALL"
	@SerializedName("type")
	private String type;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getBlockDate() {
		return blockDate;
	}

	public void setBlockDate(String blockDate) {
		this.blockDate = blockDate;
	}

	public String getDaysToMaturity() {
		return daysToMaturity;
	}

	public void setDaysToMaturity(String daysToMaturity) {
		this.daysToMaturity = daysToMaturity;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
