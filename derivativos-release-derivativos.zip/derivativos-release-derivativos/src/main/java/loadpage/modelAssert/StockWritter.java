package loadpage.modelAssert;

public class StockWritter {

	private String serie;
	private String opcao;
	private String strike;
	private String ultimo;
	private String bid;
	private String ask;
	public String getSerie() {
		return serie;
	}
	public void setSerie(String serie) {
		this.serie = serie;
	}
	public String getOpcao() {
		return opcao;
	}
	public void setOpcao(String opcao) {
		this.opcao = opcao;
	}
	public String getStrike() {
		return strike;
	}
	public void setStrike(String strike) {
		this.strike = strike;
	}
	public String getUltimo() {
		return ultimo;
	}
	public void setUltimo(String ultimo) {
		this.ultimo = ultimo;
	}
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	public String getAsk() {
		return ask;
	}
	public void setAsk(String ask) {
		this.ask = ask;
	}
	
	
	

}
