package loadpage.modelAssert;

import com.google.gson.annotations.SerializedName;

public class Powder {

	// "id": 315528,
	@SerializedName("id")
	private String id;

	// "symbol": "CYREK229",
	@SerializedName("symbol")
	private String symbol;

	// "close": 0.04,
	@SerializedName("close")
	private String close;

	// "strike": 22.91,
	@SerializedName("strike")
	private String strike;

	// "variation": -20,
	@SerializedName("variation")
	private String variation;

	// "volume": 300,
	@SerializedName("volume")
	private String volume;

	// "financial-volume": 12,
	@SerializedName("financial-volume")
	private String financialVolume;

	// "spot-symbol": "CYRE3",
	@SerializedName("spot-symbol")
	private String spotSymbol;

	// "spot-price": 18.18,
	@SerializedName("spot-price")
	private String spotPrice;

	// "spot-volatility": 47.36,
	@SerializedName("spot-volatility")
	private String spotVolatility;

	// "bid": 0.02,
	@SerializedName("bid")
	private String bid;

	// "bid-volume": 200,
	@SerializedName("bid-volume")
	private String bidVolume;

	// "ask": 0.12,
	@SerializedName("ask")
	private String ask;

	// "ask-volume": 200,
	@SerializedName("ask-volume")
	private String askVolume;

	// "open": 0.04,
	@SerializedName("open")
	private String open;

	// "high": 0.04,
	@SerializedName("high")
	private String high;

	// "low": 0.04,
	@SerializedName("low")
	private String low;

	// "series_id": 1005,
	@SerializedName("series_id")
	private String series_id;

	// "series_name": "CYREK",
	@SerializedName("series_name")
	private String series_name;

	// "due-date": "2021-11-19",
	@SerializedName("due-date")
	private String dueDate;

	// "days-to-maturity": 23,
	@SerializedName("days-to-maturity")
	private String daysToMaturity;

	// "type": "CALL",
	@SerializedName("type")
	private String type;

	// "maturity-type": "AMERICAN",
	@SerializedName("maturity-type")
	private String maturityType;

	// "interest-rate": 6.15,
	@SerializedName("interest-rate")
	private String interestRate;

	// "market-maker": null
	@SerializedName("market-maker")
	private String marketMake;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getClose() {
		return close;
	}

	public void setClose(String close) {
		this.close = close;
	}

	public String getStrike() {
		return strike;
	}

	public void setStrike(String strike) {
		this.strike = strike;
	}

	public String getVariation() {
		return variation;
	}

	public void setVariation(String variation) {
		this.variation = variation;
	}

	public String getVolume() {
		return volume;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}

	public String getFinancialVolume() {
		return financialVolume;
	}

	public void setFinancialVolume(String financialVolume) {
		this.financialVolume = financialVolume;
	}

	public String getSpotSymbol() {
		return spotSymbol;
	}

	public void setSpotSymbol(String spotSymbol) {
		this.spotSymbol = spotSymbol;
	}

	public String getSpotPrice() {
		return spotPrice;
	}

	public void setSpotPrice(String spotPrice) {
		this.spotPrice = spotPrice;
	}

	public String getSpotVolatility() {
		return spotVolatility;
	}

	public void setSpotVolatility(String spotVolatility) {
		this.spotVolatility = spotVolatility;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getBidVolume() {
		return bidVolume;
	}

	public void setBidVolume(String bidVolume) {
		this.bidVolume = bidVolume;
	}

	public String getAsk() {
		return ask;
	}

	public void setAsk(String ask) {
		this.ask = ask;
	}

	public String getAskVolume() {
		return askVolume;
	}

	public void setAskVolume(String askVolume) {
		this.askVolume = askVolume;
	}

	public String getOpen() {
		return open;
	}

	public void setOpen(String open) {
		this.open = open;
	}

	public String getHigh() {
		return high;
	}

	public void setHigh(String high) {
		this.high = high;
	}

	public String getLow() {
		return low;
	}

	public void setLow(String low) {
		this.low = low;
	}

	public String getSeries_id() {
		return series_id;
	}

	public void setSeries_id(String series_id) {
		this.series_id = series_id;
	}

	public String getSeries_name() {
		return series_name;
	}

	public void setSeries_name(String series_name) {
		this.series_name = series_name;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getDaysToMaturity() {
		return daysToMaturity;
	}

	public void setDaysToMaturity(String daysToMaturity) {
		this.daysToMaturity = daysToMaturity;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMaturityType() {
		return maturityType;
	}

	public void setMaturityType(String maturityType) {
		this.maturityType = maturityType;
	}

	public String getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}

	public String getMarketMake() {
		return marketMake;
	}

	public void setMarketMake(String marketMake) {
		this.marketMake = marketMake;
	}

}
