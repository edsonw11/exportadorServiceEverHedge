package loadpage.modelAssert;

import java.awt.FlowLayout;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MessageWaitinEverHedge extends JFrame {

	static JLabel lblWaiting = new JLabel("Aguarde...");

	static JLabel lblHeader = new JLabel("Processando");

	static Icon iconImg = new ImageIcon("/demo/gif/cachorro-imagem-animada-0819.gif");

	public MessageWaitinEverHedge() {
//		JOptionPane.showOptionDialog(null, lblWaiting.getText(), lblHeader.getText(), JOptionPane.DEFAULT_OPTION,
//				JOptionPane.INFORMATION_MESSAGE, null, new Object[] {}, null);
	
//
		setLayout(new FlowLayout(FlowLayout.CENTER));
		
		

		JLabel aguarde = new JLabel("Aguarde");

		JPanel painel = new JPanel();

		painel.add(aguarde);

		painel.setAlignmentX(CENTER_ALIGNMENT);

	
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		pack();
		painel.setVisible(true);
		setSize(300, 250);
		setLocationRelativeTo(null);

	}

}
