package loadpage.modelAssert;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class OpAberta {

	// "name": "**** collar 16/07 rolagem 1 - 0,66 finalizada",
	@SerializedName("name")
	private String name;

	// "spot-symbol": "PETR4",
	@SerializedName("spot-symbol")
	private String spot_symbol;

	// "days-to-maturity": 5,
	@SerializedName("days-to-maturity")
	private String days_to_maturity;

	// "due-date": "2021-09-17",
	@SerializedName("due-date")
	private String due_date;

	// "created-at": "2021-08-04",
	@SerializedName("created-at")
	private String created_at;

	// "spot-price": 25.44,
	@SerializedName("spot-price")
	private String spot_price;

	@SerializedName("details")
	private Object legsAbertas;
	
	
	private ArrayList<LegAberta> listLegs;
	
	
	
	
	
	
	
	



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpot_symbol() {
		return spot_symbol;
	}

	public void setSpot_symbol(String spot_symbol) {
		this.spot_symbol = spot_symbol;
	}

	public String getDays_to_maturity() {
		return days_to_maturity;
	}

	public void setDays_to_maturity(String days_to_maturity) {
		this.days_to_maturity = days_to_maturity;
	}

	public String getDue_date() {
		return due_date;
	}

	public void setDue_date(String due_date) {
		this.due_date = due_date;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getSpot_price() {
		return spot_price;
	}

	public void setSpot_price(String spot_price) {
		this.spot_price = spot_price;
	}

	
	

	public Object getLegsAbertas() {
		return legsAbertas;
	}

	public void setLegsAbertas(Object legsAbertas) {
		this.legsAbertas = legsAbertas;
	}


	
	
	public ArrayList<LegAberta> getListLegs() {
		if (listLegs == null)
			listLegs = new ArrayList<LegAberta>();
		return listLegs;
		
	}

	public void setListLegs(ArrayList<LegAberta> listLegs) {
		this.listLegs = listLegs;
	}

	@Override
	public String toString() {
		return "OpAberta [name=" + name + ", spot_symbol=" + spot_symbol + ", days_to_maturity=" + days_to_maturity
				+ ", due_date=" + due_date + ", created_at=" + created_at + ", spot_price=" + spot_price
				+ ", legsAbertas=" + legsAbertas + "]";
	}


	
	
	
}
