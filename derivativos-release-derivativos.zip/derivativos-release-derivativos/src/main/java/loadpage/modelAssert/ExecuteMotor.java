package loadpage.modelAssert;

import com.mashape.unirest.http.HttpResponse;

import java.util.Arrays;
import com.mashape.unirest.http.Unirest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.internal.LinkedTreeMap;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import loadpage.LoadPage;
import loadpage.modelAssert.Autentication;
import loadpage.modelAssert.LegAberta;
import loadpage.modelAssert.Login;
import loadpage.modelAssert.OpAberta;
import loadpage.modelAssert.Options;
import loadpage.modelAssert.Powder;
import loadpage.modelAssert.Screen;
import loadpage.modelAssert.Series;

public class ExecuteMotor {

	static Thread thread1;

	public static Autentication objAutentication = new Autentication();

	static Screen screenBackMySeires;

	static List<Stock> listStockNamesOut;

	static List<String> listaAssetStringFromFile;

	static File filePathAssets = new File(System.getProperty("user.home") + File.separator + "Desktop" + File.separator
			+ "AnaliseAsset" + File.separator + "everHedgeAnalize.txt");;

	static File fileData = new File(System.getProperty("user.home") + File.separator + "Desktop" + File.separator
			+ "AnaliseAsset" + File.separator + "data.txt");

	static UserEverHedge userEverHedge;

	static String autenticationEver = "https://api.oplab.com.br/v2/users/authenticate";

	// Tipo GET - devolve campo "symbol": "STBP3",
	public static String pathStocks = "https://api.oplab.com.br/v2/stocks";

	// Tipo GET "symbol": "STBP3" devolve campo "id": 1005,
	// https://api.oplab.com.br/v2/series/ *SPTB3*
	public static String pathSeries = "https://api.oplab.com.br/v2/series/";

	// TIPO GET devolve campo "id": 562998, https://api.oplab.com.br/v2/studies/
	// *STBP3*
	public static String pathAtivo = "https://api.oplab.com.br/v2/studies/";

	// Tipo POST
	// https://api.oplab.com.br/v2/studies/ *562998*/add_series/*1005*
	public static String pathAddSeries = "https://api.oplab.com.br/v2/studies/562998/add_series/1005";

	// Tipo GET -- pegar a lista de opcao
	// https://api.oplab.com.br/v2/studies/*STBP3*
	static String listaOpcoesEver = "https://api.oplab.com.br/v2/studies/";

	static String listaOpcoesEverCurrent = "https://api.oplab.com.br/v2/studies/current";

	// tipo DELETE https://api.oplab.com.br/v2/studies/*562998*/remove_series/*1005*
	public static String pathRemoveSeries = "https://api.oplab.com.br/v2/studies/562998/remove_series/1005";

	public static HttpResponse<String> autenticar(String pathService) throws UnirestException {

//		HttpResponse<String> response = Unirest.get(pathService).header("access-control-allow-headers",
//				"DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range,Access-Token,Authorization")
//				.header("authorization", "Basic ZWRzc29udzExQGdtYWlsLmNvbTp0ZWNoMjA4MQ==")
//				.header("access-token",
//						"O62AjLdEI/aYU450Y2z7pPJmNBpap7wqe9KCKoNz3dLTHFz8o7q917MqlYfAJl3LtPHuSutvC4wTwgnDBBl/SQ==--HN/OWBlOW9kK1IKXM+Dw8g==--6Pbbam5VueoWsrgRKkyTmQ==")
//				.header("email", "edsonw11@gmail.com").header("password", "tech2081")
//				.header("cache-control", "no-cache").header("postman-token", "9f127d97-6815-3fe9-e4d2-eff406e5e17c")
//				.asString();
//
//		return response;

		if (objAutentication.isLogado()) {

			HttpResponse<String> response = Unirest.get(pathService).header("access-control-allow-headers",
					"DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range,Access-Token,Authorization")
					.header("authorization", "Basic ZWRzc29udzExQGdtYWlsLmNvbTp0ZWNoMjA4MQ==")
					.header("access-token",
							"O62AjLdEI/aYU450Y2z7pPJmNBpap7wqe9KCKoNz3dLTHFz8o7q917MqlYfAJl3LtPHuSutvC4wTwgnDBBl/SQ==--HN/OWBlOW9kK1IKXM+Dw8g==--6Pbbam5VueoWsrgRKkyTmQ==")
					.header("email", userEverHedge.getEmailTrava()).header("password", userEverHedge.getPasswordTrava())
					.header("cache-control", "no-cache").header("postman-token", "9f127d97-6815-3fe9-e4d2-eff406e5e17c")
					.asString();

			return response;
		} else
			return null;
	}

	public static HttpResponse<String> autenticarPost(String pathService) throws UnirestException {

		if (objAutentication.isLogado()) {
			// HttpResponse<String> response =
			// Unirest.post("https://api.oplab.com.br/v2/studies/563482/add_series/1005")
			HttpResponse<String> response = Unirest.post(pathService).header("access-token",
					"eXV2qcmJyAAFyyvj8pAk5Y7Zls7xqA6txCHkCRZHf/qqzslCgybwTixHPXzJyHZKOjmrIP63fuyYkiTdqA7OXg==--aOygoOSYfnNySZ0NBBfA1g==--RQfsdyFQ4ERPhZmt+E8JMA==")
					.header("email", userEverHedge.getEmailTrava()).header("password", userEverHedge.getPasswordTrava())
					.header("cache-control", "no-cache").header("postman-token", "3f7a4fc7-2c9c-63cc-4d48-47ad7c8e24d0")
					.asString();

			return response;

		} else
			return null;

	}

	public static HttpResponse<String> autenticarRemove(String pathService) throws UnirestException {

		if (objAutentication.isLogado()) {
			// HttpResponse<String> response =
			// Unirest.post("https://api.oplab.com.br/v2/studies/563482/add_series/1005")
			HttpResponse<String> response = Unirest.delete(pathService).header("access-token",
					"eXV2qcmJyAAFyyvj8pAk5Y7Zls7xqA6txCHkCRZHf/qqzslCgybwTixHPXzJyHZKOjmrIP63fuyYkiTdqA7OXg==--aOygoOSYfnNySZ0NBBfA1g==--RQfsdyFQ4ERPhZmt+E8JMA==")
					.header("email", userEverHedge.getEmailTrava()).header("password", userEverHedge.getPasswordTrava())
					.header("cache-control", "no-cache").header("postman-token", "3f7a4fc7-2c9c-63cc-4d48-47ad7c8e24d0")
					.asString();

			return response;
		} else
			return null;

	}

	// retorna a lista de stocks
	private static List<Stock> doListStocks(HttpResponse<String> response)
			throws JsonSyntaxException, UnirestException, IOException {

		listaAssetStringFromFile = new ArrayList<String>(doReadFile(filePathAssets.getAbsolutePath()));

		Stock[] listStocks;

		if (!(listaAssetStringFromFile.size() > 0)) {

			listStocks = new Gson().fromJson(response.getBody(), Stock[].class);

		} else {
			listStocks = createStockForList(listaAssetStringFromFile);
		}

		List<Stock> listStockNames = new ArrayList<Stock>();

		Screen sFeedBack = new Screen();

		int i = 0;

		for (Stock stockObj : listStocks) {

			Ativo ativoId = null;

			SerieAvailable SerieAvailableForDelete = null;

			// doCarregaListaAssets();

			if (listaAssetStringFromFile.contains(stockObj.getSymbol())) {

				// System.out.println(i++ + ">> Stock : " + stockObj.getSymbol());
				listStockNames.add(stockObj);

				List<SerieAvailable> listStockSeriesAvaliableNames = new ArrayList<SerieAvailable>();

				SerieAvailable[] listStocksSerieAvailable = new Gson()
						.fromJson(autenticar(pathSeries + stockObj.getSymbol()).getBody(), SerieAvailable[].class);

				for (SerieAvailable sAObj : listStocksSerieAvailable) {

					SerieAvailableForDelete = sAObj;

					// System.out.println(i++ + ">> StockAvailable : " + stockObj.getSymbol() + " "
					// + sAObj.getName() + " "
					// + sAObj.getId());
					listStockSeriesAvaliableNames.add(sAObj);

					List<Ativo> listStockSeriesAvaliableAtivoIdNames = new ArrayList<Ativo>();

					// System.out.println("#### ===== Stock ATIVO listStockNamesOut ===== ### : " +
					// stockObj.getSymbol());

					ativoId = new Gson().fromJson(autenticar(pathAtivo + stockObj.getSymbol()).getBody(), Ativo.class);

					// if (stockObj.getSymbol().equals("STBP3")){
					// System.out.println(i++ + ">> StockAvailable : " + stockObj.getSymbol() + " "
					// + sAObj.getName() + " "
					// + sAObj.getId() + " AtivoId : " + ativoId.getId());

					// https://api.oplab.com.br/v2/studies/ativoId.getId()/add_series/sAObj.getId()
					String pathAdd = "https://api.oplab.com.br/v2/studies/" + ativoId.getId() + "/add_series/"
							+ sAObj.getId();

					/// System.out.println(" pathAdd : " + pathAdd);

					autenticarPost(pathAdd);

					// break;
					// }

					listStockSeriesAvaliableAtivoIdNames.add(ativoId);

				}

				Screen sTMP = (Screen) LoadPage.doGetAssert(listaOpcoesEver + stockObj.getSymbol());

				sFeedBack.getListaStockWritter().addAll(sTMP.getListaStockWritter());

				for (SerieAvailable sAObj : listStocksSerieAvailable) {

					// System.out.println(i++ + ">> REMOVENDO = StockAvailable : " +
					// stockObj.getSymbol() + " "
					// + sAObj.getName() + " " + sAObj.getId());

					String pathRemove = "https://api.oplab.com.br/v2/studies/" + ativoId.getId() + "/remove_series/"
							+ sAObj.getId();

					// System.out.println(" >>>>> pathRemove : " + pathRemove);

					autenticarRemove(pathRemove);

				}

			}
			listStockNamesOut = listStockNames;
		}

		LoadPage.createWorkbookEverHedge(sFeedBack.getListaStockWritter(), userEverHedge.getDir());

		doBackMySeries();

		return listStockNames;

	}

	private static void doBackMySeries() throws JsonSyntaxException, UnirestException {
		// listaOpcoesEverCurrent

		Options listOpcoes = null;

		List<Series> listaSeireTMP = new ArrayList<Series>();

		List<StockWritter> listaStockWritter = new ArrayList<StockWritter>();

		LinkedTreeMap objSeries = new Gson().fromJson(screenBackMySeires.getListSeries().toString(),
				LinkedTreeMap.class);

		Iterator iterator = ((Map) objSeries).entrySet().iterator();

		while (iterator.hasNext()) {

			Map.Entry entry = (Map.Entry) iterator.next();
			// System.out.println(entry.getKey() + "->" + entry.getValue());

			Series objSerie = new Gson().fromJson(entry.getValue().toString(), Series.class);

			Iterator iteratorOp = ((Map) objSerie.getListOptionOBJs()).entrySet().iterator();

			while (iteratorOp.hasNext()) {

				Map.Entry entryOp = (Map.Entry) iteratorOp.next();

				Options opSeries = new Gson().fromJson(entryOp.getValue().toString(), Options.class);

				StockWritter sW = new StockWritter();

				sW.setSerie(objSerie.getName());
				sW.setOpcao(entryOp.getKey().toString());
				sW.setStrike(opSeries.getStrike());
				sW.setUltimo(opSeries.getClose());
				sW.setBid(opSeries.getBid());
				sW.setAsk(opSeries.getAsk());

				// System.out.println("Serie : " + sW.getSerie());
				// System.out.println("Opcao : " + sW.getOpcao());
				// System.out.println("Strike : " + sW.getStrike());
				// System.out.println("Ultimo : " + sW.getUltimo());
				// System.out.println("Bid : " + sW.getBid());
				// System.out.println("Ask : " + sW.getAsk());

				// System.out.println("screen.getId()" + screenBackMySeires.getId());
				listaStockWritter.add(sW);

				Ativo ativoId = new Gson().fromJson(
						autenticar(pathAtivo + screenBackMySeires.getTarget().getSymbol()).getBody(), Ativo.class);

				String pathAdd = "https://api.oplab.com.br/v2/studies/" + screenBackMySeires.getId() + "/add_series/"
						+ sW.getOpcao();

				// System.out.println(" pathAdd : " + pathAdd);

				autenticarPost(pathAdd);

			}
			System.exit(0);

		}

	}

	private static Stock[] createStockForList(List<String> doReadFile) {
		List<Stock> listaStockFromFile = new ArrayList<Stock>();

		for (String s : doReadFile) {
			Stock stock = new Stock();
			stock.setSymbol(s);
			listaStockFromFile.add(stock);
		}

		Stock[] arrayStock = listaStockFromFile.toArray(new Stock[listaStockFromFile.size()]);

		return arrayStock;
	}

	public static void doCreateFile() throws IOException, JsonSyntaxException, UnirestException { // Aqui retorna String

		String home = System.getProperty("user.home");

		File myDir = new File(home + File.separator + "Desktop" + File.separator + "AnaliseAsset");
		myDir.mkdir();

		if (!filePathAssets.exists()) {

			// System.out.println("arquivo não existe");

			filePathAssets.createNewFile();

			HttpResponse<String> response = autenticar(pathStocks);

			Stock[] listStocks = new Gson().fromJson(response.getBody(), Stock[].class);

			writterFileAnalize(filePathAssets.getAbsolutePath(), Arrays.asList(listStocks));

			// System.out.println("criando arquivo File.txt em..." +
			// filePathAssets.getAbsolutePath());

		}

	}

	public static List<String> doReadFile(String path) throws IOException {
		BufferedReader buffRead = new BufferedReader(new FileReader(path));
		String linhaAsset = "";

		List<String> assetFindList = new ArrayList<String>();

		while ((linhaAsset = buffRead.readLine()) != null) {

			if (linhaAsset != null) {
				if (!linhaAsset.contains("*")) {
					// System.out.println(linhaAsset.substring(linhaAsset.indexOf("-") + 2,
					// linhaAsset.length()));
					assetFindList.add(linhaAsset.substring(linhaAsset.indexOf("-") + 2, linhaAsset.length()));

				} else {
					continue;
				}

			}

		}
		buffRead.close();

		return assetFindList;
	}

	public static void writterFileAnalize(String path, List<Stock> listStockNamesOut) throws IOException {
		BufferedWriter buffWrite = new BufferedWriter(new FileWriter(path));
		String linha = "";

		int i = 0;
		for (Stock s : listStockNamesOut) {
			String notAvaliable = getAvailableAsset(s);
			buffWrite.write(notAvaliable + i++ + " - " + s.getSymbol());
			buffWrite.append(linha + "\n");
		}

		buffWrite.close();
	}

	// por padrao deixar 3 Assets habilitadas
	private static String getAvailableAsset(Stock s) {

		String AssetAvailable[] = { "STBP3", "VIVA3", "PETR4" };
		String notAvailable = "*";

		if (Arrays.asList(AssetAvailable).contains(s.getSymbol()))
			notAvailable = "";

		return notAvailable;
	}

	// retorna a lista de stocks
	private static List<SerieAvailable> doListSeriesAvailable(List<Stock> listStock)
			throws JsonSyntaxException, UnirestException {

		List<SerieAvailable> listStockSeriesAvaliableNames = new ArrayList<SerieAvailable>();

		int j = 0;

		for (Stock stockObj : listStock) {

			// System.out.println(j++ + "#### ===== Stock ===== ### : " +
			// stockObj.getSymbol());

			SerieAvailable[] listStocksSerieAvailable = new Gson()
					.fromJson(autenticar(pathSeries + stockObj.getSymbol()).getBody(), SerieAvailable[].class);

			int i = 0;

			for (SerieAvailable sAObj : listStocksSerieAvailable) {
				// System.out.println(i++ + ">> StockAvailable : " + stockObj.getSymbol() + " :
				// " + sAObj.getName());
				listStockSeriesAvaliableNames.add(sAObj);

			}

		}

		return listStockSeriesAvaliableNames;

	}

	private static List<Ativo> doListAtivoId(List<SerieAvailable> listStockSeriesAvaliableNames)
			throws JsonSyntaxException, UnirestException {

		List<Ativo> listStockSeriesAvaliableAtivoIdNames = new ArrayList<Ativo>();

		int j = 0;

		for (Stock stockObj : listStockNamesOut) {

			// System.out.println(j++ + "#### ===== Stock ATIVO listStockNamesOut ===== ###
			// : " + stockObj.getSymbol());

			Ativo ativoId = new Gson().fromJson(autenticar(pathAtivo + stockObj.getSymbol()).getBody(), Ativo.class);

			int i = 0;

			// if (stockObj.getSymbol().equals("STBP3")){
			// System.out.println(i++ + ">> StockAvailable : " + stockObj.getSymbol() + " :
			// " + ativoId.getId());
			// break;
			// }

			listStockSeriesAvaliableAtivoIdNames.add(ativoId);

		}

		return listStockSeriesAvaliableAtivoIdNames;

	}

	private static void doPlayExport() {

		PlayExport play = new PlayExport();

	}

	private static UserEverHedge doBuildUserEverHedge() throws IOException {
		userEverHedge = new UserEverHedge();

		List<String> data = getData();

		try {
			userEverHedge.setEmail(data.get(0));
			userEverHedge.setPassword(data.get(1));
			userEverHedge.setDir(data.get(2));

			doAuthentication();

			if (objAutentication.isLogado()) {
				userEverHedge.setEmailTrava("edsonw11@gmail.com");
				userEverHedge.setPasswordTrava("tech2081");
			} else {
				userEverHedge.setEmailTrava("userInvalido");
				userEverHedge.setPasswordTrava("senhaInvalida");
			}

		} catch (Exception e) {

			doEverHedgeMessageErro();

		}

		return userEverHedge;

	}

	private static void doEverHedgeMessageErro() {
		JOptionPane.showConfirmDialog(null, " Por favor preecher os dados de acesso em : " + fileData.getAbsolutePath()
				+ ", e execute novamente o Sistema! ", "", JOptionPane.WARNING_MESSAGE);

		System.exit(0);
	}

	public static List<String> getData() throws IOException {

		List<String> listaDataUser = new ArrayList<String>();

		String[] listaData = { "email : ", "password : ",
				"dir : " + filePathAssets.getAbsolutePath().replace(".txt", "") };

		File myDir = new File(
				System.getProperty("user.home") + File.separator + "Desktop" + File.separator + "AnaliseAsset");
		myDir.mkdir();

		if (!fileData.exists()) {

			System.out.println("arquivo não existe");
			fileData.createNewFile();

			writterDataDefault(fileData.getAbsolutePath(), Arrays.asList(listaData));

			System.out.println("criando arquivo File.txt em..." + fileData.getAbsolutePath());

		} else {

			BufferedReader buffRead = new BufferedReader(new FileReader(fileData));
			String linhaData = "";

			while ((linhaData = buffRead.readLine()) != null) {

				if (linhaData != null) {
					if (linhaData.contains(": ")) {
						// System.out.println(linhaData.substring(linhaData.indexOf(": ") + 2,
						// linhaData.length()));
						listaDataUser.add(linhaData.substring(linhaData.indexOf(": ") + 2, linhaData.length()));

					} else {
						continue;
					}

				}

			}
			buffRead.close();
		}

		return listaDataUser;
	}

	public static void writterDataDefault(String path, List<String> listaData) throws IOException {
		BufferedWriter buffWrite = new BufferedWriter(new FileWriter(path));
		String linha = "";

		for (String s : listaData) {

			buffWrite.write(s);
			buffWrite.append(linha + "\n");
		}

		buffWrite.close();
	}

	private static Autentication doAuthentication() throws UnirestException {

		HttpResponse<String> response = Unirest.post("https://api.oplab.com.br/v2/users/authenticate")
				.header("content-type", "application/json").header("cache-control", "no-cache")
				.header("postman-token", "e32e67f8-f492-32e2-6fb1-256bd9a6bbec")
				.body("{\n\t   \"postId\": 101, \n       \"email\": \"" + userEverHedge.getEmail()
						+ "\",\n       \"password\": \"" + userEverHedge.getPassword() + "\" }")
				.asString();

		try {
			objAutentication = new Gson().fromJson(response.getBody().trim(), Autentication.class);

			if (objAutentication != null && objAutentication.getAccess_token().length() > 0) {
				objAutentication.setLogado(true);
			} else {
				objAutentication = new Autentication();

				objAutentication.setLogado(false);
				objAutentication.setAccess_token("erro login");
			}

		} catch (Exception e) {
			objAutentication = new Autentication();

			objAutentication.setLogado(false);
			objAutentication.setAccess_token("erro login");

		}

		// System.out.println(objAutentication);

		return objAutentication;
	}

	public static void main(String[] args) throws JsonSyntaxException, IOException {

		doPlayExport();
		
	//	thread1 = new Thread(t1);

		

	}

	
	private static Runnable t1 = new Runnable() {
		public void run() {

			PlayExport.msgWaiting = new MessageWaitinEverHedge();

		}
	};

	public static void initialExec() {
		
		//thread1.start();

		try {

			try {
				userEverHedge = doBuildUserEverHedge();
				
			

				if (objAutentication.isLogado()) {
					screenBackMySeires = new Gson().fromJson(autenticar(listaOpcoesEverCurrent).getBody(),
							Screen.class);
					doCreateFile();

					doListStocks(autenticar(pathStocks));

					// doListAtivoId(doListSeriesAvailable(doListStocks(autenticar(pathStocks))));
				} else {
					doEverHedgeMessageErro();
				}

			} catch (IOException e) {

			}
		} catch (UnirestException e) {

			e.printStackTrace();
		}

	}

	public static void initial() {

		initialExec();

	}

}
