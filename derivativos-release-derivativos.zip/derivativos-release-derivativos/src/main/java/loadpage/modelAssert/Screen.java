package loadpage.modelAssert;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.SerializedName;

public class Screen {


   private String id;
   private Target target;
   
   private List<StockWritter> listaStockWritter;


    @SerializedName("interest-rate-id")
    private String interestRateId;

    @SerializedName("interest-rate")
    private String interestRate;

    @SerializedName("locked-days-to-maturity")
    private String lockedDaysToMaturity;

    @SerializedName("locked-spot-price")
    private String lockedSpotPrice;

    @SerializedName("locked-volatility")
    private String lockedVolatility;

    @SerializedName("ui-settings")
    private Object uiSettings;


    @SerializedName("series")
    private Object listSeries;
    
    
	private ArrayList<Series> listaSeriesfront;



    public Object getListSeries() {
        return listSeries;
    }

    public void setListSeries(Object listSeries) {
        this.listSeries = listSeries;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Target getTarget() {
        return target;
    }

    public void setTarget(Target target) {
        this.target = target;
    }

    public String getInterestRateId() {
        return interestRateId;
    }

    public void setInterestRateId(String interestRateId) {
        this.interestRateId = interestRateId;
    }

    public String getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(String interestRate) {
        this.interestRate = interestRate;
    }

    public String getLockedDaysToMaturity() {
        return lockedDaysToMaturity;
    }

    public void setLockedDaysToMaturity(String lockedDaysToMaturity) {
        this.lockedDaysToMaturity = lockedDaysToMaturity;
    }

    public String getLockedSpotPrice() {
        return lockedSpotPrice;
    }

    public void setLockedSpotPrice(String lockedSpotPrice) {
        this.lockedSpotPrice = lockedSpotPrice;
    }

    public String getLockedVolatility() {
        return lockedVolatility;
    }

    public void setLockedVolatility(String lockedVolatility) {
        this.lockedVolatility = lockedVolatility;
    }

	public Object getUiSettings() {
		return uiSettings;
	}

	public void setUiSettings(Object uiSettings) {
		this.uiSettings = uiSettings;
	}

	public ArrayList<Series> getListaSeriesfront() {
		if(listaSeriesfront == null)
			listaSeriesfront = new ArrayList<Series>();
		return listaSeriesfront;
	}

	public void setListaSeriesfront(ArrayList<Series> listaSeriesfront) {
		this.listaSeriesfront = listaSeriesfront;
	}

	public List<StockWritter> getListaStockWritter() {
		if(listaStockWritter == null)
			listaStockWritter = new ArrayList<StockWritter>();
		return listaStockWritter;
	}

	public void setListaStockWritter(List<StockWritter> listaStockWritter) {
		this.listaStockWritter = listaStockWritter;
	}
	
	



}