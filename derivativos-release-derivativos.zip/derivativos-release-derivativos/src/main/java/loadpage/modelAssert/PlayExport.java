package loadpage.modelAssert;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PlayExport extends JFrame {

	static JButton btnPlay, btnCancel;

	static MessageWaitinEverHedge msgWaiting;
	
	static JLabel lblWaiting = new JLabel("Aguarde...");

	private JPanel panel = new JPanel();

	public PlayExport() {

		super("Gerar Planinlha");

		setLayout(new FlowLayout(FlowLayout.CENTER));

		btnPlay = new JButton("play");

		btnCancel = new JButton("Cancel");

		btnPlay.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent evento) {

				// doPlayExport();
				
			

				ExecuteMotor.initial();

				// msgWaiting.dispose();

			}
		});

		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evento) {
				System.exit(0);

			}

		});
		
		lblWaiting.setVisible(false);
		
		panel.add(btnPlay);
		panel.add(btnCancel);
		panel.add(lblWaiting);
		panel.setAlignmentX(CENTER_ALIGNMENT);
		add(panel);
		pack();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(220, 220);
		setLocationRelativeTo(null);
		setVisible(true);

	}

	
	
	
	
	private static void doPlayExport() {
		
		

	//	msgWaiting = new MessageWaitinEverHedge();
	

	}

}
