package loadpage.modelAssert;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

//import com.toedter.calendar.JDateChooser;

public class DataMainClass extends JFrame {

	JFrame frame = new JFrame();

	public DataMainClass() {

		Icon ico = new ImageIcon("icones/xpto.gif");
		JLabel label = new JLabel(ico);

		frame.getContentPane().add(label);
		frame.setSize(101, 101);
		frame.setUndecorated(true); // tira a borda superior com os três botões do windows
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

	}

	Runnable run = new Runnable() {
		@Override
		public void run() {
			Analisando2 analis = null;
			try { 

				analis = new Analisando2(); // Obeto que contem o frame com a Gif animada. 
				analis.setVisible(true);
				// a gif tem que aparecer dai pra baixo. 


				PlanarImage picture = JAI.create("fileload", "c:/Imagens/particulas.jpg"); 

				Imagem um = new Imagem (picture); 
				um.binarize(); 
				Filtro filtro1 = new Filtro("c:/Outputbin/Binarizada.bmp"); 
				filtro1.Mediana(); 
				filtro1.eliminaBordas(); 
				File file1 = new File("c:/Outputbin/Filtrada2.bmp"); 
				BufferedImage picture2 = ImageIO.read(file1); 
				Contador cont1 = new Contador(picture2); 
				quantidade = cont1.contaParticulas(); 

				// a gif só aparece deste ponto em diante 

				textField1.setText(String.valueOf(quantidade)); 

				jButton3.setEnabled(true); 
			} catch (IOException ex) { 
				Logger.getLogger(Teste.class.getName()).log(Level.SEVERE, null, ex); 

			}finally{
					analis.dispose();
						} 


		}

	}; new Thread(run).start();

	public static void main(String[] args) {
		new DataMainClass();
	}

}
