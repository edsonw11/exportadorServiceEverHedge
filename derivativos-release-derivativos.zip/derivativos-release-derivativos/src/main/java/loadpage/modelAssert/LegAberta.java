package loadpage.modelAssert;

import com.google.gson.annotations.SerializedName;

public class LegAberta {
	
	// "symbol": "PETRI286",
	@SerializedName("symbol")
	private String symbol;



	// "action": "SELL",
	@SerializedName("action")
	private String action;

	// "instrument-type": "CALL",
	@SerializedName("instrument-type")
	private String instrument_type;

	// "strike": 26.35,
	@SerializedName("strike")
	private String strike;

	// "spot-price": 26.27,
	@SerializedName("spot-price")
	private String spot_price;

	// "amount": 1000,
	@SerializedName("amount")
	private String amount;

	// "days-to-maturity": 5,
	@SerializedName("days-to-maturity")
	private String days_to_maturity;

	// "due-date": "2021-09-17",
	@SerializedName("due-date")
	private String due_date;

	// "price-in": 0.91,
	@SerializedName("price")
	private String price_in;
	
	// "maturity-type": "AMERICAN"
	@SerializedName("maturity-type")
	private String maturity_type;
	
	

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getInstrument_type() {
		return instrument_type;
	}

	public void setInstrument_type(String instrument_type) {
		this.instrument_type = instrument_type;
	}

	public String getStrike() {
		return strike;
	}

	public void setStrike(String strike) {
		this.strike = strike;
	}

	public String getSpot_price() {
		return spot_price;
	}

	public void setSpot_price(String spot_price) {
		this.spot_price = spot_price;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getDays_to_maturity() {
		return days_to_maturity;
	}

	public void setDays_to_maturity(String days_to_maturity) {
		this.days_to_maturity = days_to_maturity;
	}

	public String getDue_date() {
		return due_date;
	}

	public void setDue_date(String due_date) {
		this.due_date = due_date;
	}

	public String getPrice_in() {
		return price_in;
	}

	public void setPrice_in(String price_in) {
		this.price_in = price_in;
	}

	public String getMaturity_type() {
		return maturity_type;
	}

	public void setMaturity_type(String maturity_type) {
		this.maturity_type = maturity_type;
	}


	
	
	
	
	
	
	
            

}
