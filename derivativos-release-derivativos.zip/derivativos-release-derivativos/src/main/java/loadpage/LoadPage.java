package loadpage;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import loadpage.modelAssert.Autentication;
import loadpage.modelAssert.LegAberta;
import loadpage.modelAssert.Login;
import loadpage.modelAssert.OpAberta;
import loadpage.modelAssert.Options;
import loadpage.modelAssert.Powder;
import loadpage.modelAssert.Screen;
import loadpage.modelAssert.Series;
import loadpage.modelAssert.StockWritter;

public class LoadPage {

	static String pathSaveFileIOS = "/Users/edson/Downloads/estrategiasEverHedge.xls";

	static String pathSaveFileWindows = "/c:/edson/Downloads/estrategiasEverHedge.xls";

	static String autentication = "https://api.oplab.com.br/v2/users/authenticate";

	static String listaOpcoes = "https://api.oplab.com.br/v2/studies/current";

	public static String posicoesAbertas = "https://api.oplab.com.br/v2/positions";

	public static String pathPowders = "https://api.oplab.com.br/v2/options/powders";

	static String autenticationEver = "https://api.oplab.com.br/v2/users/authenticate";

	// Tipo GET - devolve campo "symbol": "STBP3",
	public static String pathstocks = "https://api.oplab.com.br/v2/stocks";

	// Tipo GET "symbol": "STBP3" devolve campo "id": 1005,
	public static String pathSeries = "https://api.oplab.com.br/v2/series/STBP3";

	// TIPO GET devolve campo "id": 562998,
	public static String pathAtivo = "https://api.oplab.com.br/v2/studies/STBP3";

	// Tipo POST
	public static String pathAddSeries = "https://api.oplab.com.br/v2/studies/562998/add_series/1005";

	// Tipo GET -- pegar a lista de opcao
	static String listaOpcoesEver = "https://api.oplab.com.br/v2/studies/STBP3";

	// tipo DELETE
	public static String pathRemoveSeries = "https://api.oplab.com.br/v2/studies/562998/remove_series/1005";

	static int numeroDeExtrategias = 0;

	public static List<Powder> doGetAssertPowders(String objFind) throws UnirestException {

		HttpResponse<String> response = Unirest.get(objFind).header("access-control-allow-headers",
				"DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range,Access-Token,Authorization")
				.header("authorization", "Basic ZWRzc29udzExQGdtYWlsLmNvbTp0ZWNoMjA4MQ==")
				.header("access-token",
						"O62AjLdEI/aYU450Y2z7pPJmNBpap7wqe9KCKoNz3dLTHFz8o7q917MqlYfAJl3LtPHuSutvC4wTwgnDBBl/SQ==--HN/OWBlOW9kK1IKXM+Dw8g==--6Pbbam5VueoWsrgRKkyTmQ==")
				.header("email", "edsonw11@gmail.com").header("password", "tech2081")
				.header("cache-control", "no-cache").header("postman-token", "9f127d97-6815-3fe9-e4d2-eff406e5e17c")
				.asString();

		return doBuildScreenPowders(response);

	}

	private static List<Powder> doBuildScreenPowders(HttpResponse<String> response) {

		Powder[] obj = new Gson().fromJson(response.getBody(), Powder[].class);

		List<Powder> listaOperacoesAbertas = new ArrayList<Powder>();

		int i = 0;

		for (Powder obA : obj) {
			// if (obA.getType().equals("PUT")) {
			if (obA.getSymbol().length() > 1)
				listaOperacoesAbertas.add(obA);
//					System.out.println(i++ + " - " + obA.getType() + " - " + obA.getSpotSymbol() + "; ask :"
//							+ obA.getAsk() + "; bid : " + obA.getBid());

			// }
		}

		return listaOperacoesAbertas;

	}

	public static void createWorkbookPowder(List<Powder> listPowder) throws IOException {

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("NovaEstrategia");

		sheet.setDefaultColumnWidth(15);
		sheet.setDefaultRowHeight((short) 400);

		int rownum = 0;
		int cellnum = 1;
		Cell cell;
		Row row;

		// Configurando estilos de células (Cores, alinhamento, formatação, etc..)
		HSSFDataFormat numberFormat = workbook.createDataFormat();

		CellStyle headerStyle = workbook.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
		headerStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		CellStyle textStyle = workbook.createCellStyle();
		textStyle.setAlignment(CellStyle.ALIGN_LEFT);
		textStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		CellStyle numberStyle = workbook.createCellStyle();

		numberStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		// Configurando Header
		row = sheet.createRow(rownum++);
		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Type");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Symbol");

//			cell = row.createCell(cellnum++);
//			cell.setCellStyle(headerStyle);
//			cell.setCellValue("series_name");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Strike");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("bid");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("ask");

		// Adicionando os dados dos produtos na planilha
		for (Powder op : listPowder) {

			row = sheet.createRow(rownum++);
			cellnum = 1;

			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyle);
			cell.setCellValue(op.getType());
			numeroDeExtrategias++;

			// row = sheet.createRow(rownum++);
			// cellnum = 2;

			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyle);
			cell.setCellValue(op.getSymbol());

//					  cell = row.createCell(cellnum++);
//					  cell.setCellStyle(textStyle);
//					  cell.setCellValue(op.getSeries_name());

			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyle);
			cell.setCellValue(op.getStrike());

			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyle);
			cell.setCellValue(op.getBid());

			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyle);
			cell.setCellValue(op.getAsk());

		}

		try {

			JFileChooser fc = new JFileChooser();

			int returnVal = fc.showSaveDialog(new JFrame());

			// Escrevendo o arquivo em disco
			FileOutputStream out = new FileOutputStream(fc.getSelectedFile() + ".xls");

			JOptionPane.showConfirmDialog(null, numeroDeExtrategias + " Artefatps exportada com com Sucesso!!", "",
					JOptionPane.WARNING_MESSAGE);

			//System.out.println("Success!!");

			numeroDeExtrategias = 0;

			workbook.write(out);
			out.close();
			workbook.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.exit(0);

	}

	public static void doExportaPowders() throws Exception {

		// Powder powder = (Powder) doGetAssertPowders(pathPowders);

		createWorkbookPowder(doGetAssertPowders(pathPowders));

	}

	public static void main(String[] args) throws Exception {

		doExportaPowders();

		// List opAbertas = doGetAssertOPAbertas(posicoesAbertas,
		// Login.objAutentication);

		/// createWorkbook(doGetAssertOPAbertas(posicoesAbertas,
		/// Login.objAutentication));

		// System.out.println(" ************** doGetAssertOPAbertas() " +
		// opAbertas.get(0)+ " ************** ");
		// -- Screen screen = (Screen) doGetAssert(listaOpcoes);

		// System.out.println(" ************** doGetAssert() " + screen.getTarget() + "
		// ************** ");

		// Inicia tela para exportar estrategia
		// doExportador();

	}

	private static void doExportador() {
		Login login = new Login();

		login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		login.setSize(210, 210);
		login.setVisible(true);
	}

	private static Autentication doAuthentication(String email, String password) throws UnirestException {

//		HttpResponse<String> response = Unirest.post("https://api.oplab.com.br/v2/users/authenticate")
//				  .header("content-type", "application/json")
//				  .header("cache-control", "no-cache")
//				  .header("postman-token", "e32e67f8-f492-32e2-6fb1-256bd9a6bbec")
//				  .body("{\n\t   \"postId\": 101, \n       \"email\": \"edsonw11@gmail.com\",\n       \"password\": \"tech2081\" }")
//				  .asString();

		HttpResponse<String> response = Unirest.post("https://api.oplab.com.br/v2/users/authenticate")
				.header("content-type", "application/json").header("cache-control", "no-cache")
				.header("postman-token", "e32e67f8-f492-32e2-6fb1-256bd9a6bbec")
				.body("{\n\t   \"postId\": 101, \n       \"email\": \"" + email + "\",\n       \"password\": \""
						+ password + "\" }")
				.asString();

		//System.out.println(response.getBody());

		Autentication objAutentication = new Gson().fromJson(response.getBody().trim(), Autentication.class);

		//System.out.println(objAutentication);
		return objAutentication;
	}

	public static void createWorkbook(List<OpAberta> opAbertas) throws IOException {

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Operacoes");

		sheet.setDefaultColumnWidth(15);
		sheet.setDefaultRowHeight((short) 400);

		int rownum = 0;
		int cellnum = 1;
		Cell cell;
		Row row;

		// Configurando estilos de células (Cores, alinhamento, formatação, etc..)
		HSSFDataFormat numberFormat = workbook.createDataFormat();

		CellStyle headerStyle = workbook.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
		headerStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		CellStyle textStyle = workbook.createCellStyle();
		textStyle.setAlignment(CellStyle.ALIGN_LEFT);
		textStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		CellStyle numberStyle = workbook.createCellStyle();

		numberStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		// Configurando Header
		row = sheet.createRow(rownum++);
		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Nome estrategia");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Symbol");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Action");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Strike");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("PrecoCompra");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Amount");

		// Adicionando os dados dos produtos na planilha
		for (OpAberta op : opAbertas) {

			row = sheet.createRow(rownum++);
			cellnum = 1;

			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyle);
			cell.setCellValue(op.getName());
			numeroDeExtrategias++;

			for (LegAberta leg : op.getListLegs()) {

				row = sheet.createRow(rownum++);
				cellnum = 2;

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getSymbol());

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getAction());

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getStrike());

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getPrice_in());

				cell = row.createCell(cellnum++);
				cell.setCellStyle(textStyle);
				cell.setCellValue(leg.getAmount());
			}

		}

		try {

			JFileChooser fc = new JFileChooser();

			int returnVal = fc.showSaveDialog(new JFrame());

			// Escrevendo o arquivo em disco
			FileOutputStream out = new FileOutputStream(fc.getSelectedFile() + ".xls");

			JOptionPane.showConfirmDialog(null, numeroDeExtrategias + "estrategias exportada com com Sucesso!!", "",
					JOptionPane.WARNING_MESSAGE);

			//System.out.println("Success!!");

			numeroDeExtrategias = 0;

			workbook.write(out);
			out.close();
			workbook.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static Object doGetAssert(String objFind) throws UnirestException, IOException {

		HttpResponse<String> response = Unirest.get(objFind).header("access-control-allow-headers",
				"DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range,Access-Token,Authorization")
				.header("authorization", "Basic ZWRzc29udzExQGdtYWlsLmNvbTp0ZWNoMjA4MQ==")
				.header("access-token",
						"O62AjLdEI/aYU450Y2z7pPJmNBpap7wqe9KCKoNz3dLTHFz8o7q917MqlYfAJl3LtPHuSutvC4wTwgnDBBl/SQ==--HN/OWBlOW9kK1IKXM+Dw8g==--6Pbbam5VueoWsrgRKkyTmQ==")
				.header("email", "edsonw11@gmail.com").header("password", "tech2081")
				.header("cache-control", "no-cache").header("postman-token", "9f127d97-6815-3fe9-e4d2-eff406e5e17c")
				.asString();

		return doBuildScreen(response);

	}

	public static List<OpAberta> doGetAssertOPAbertas(String objFind, Autentication autentication)
			throws UnirestException {

		HttpResponse<String> response = Unirest.get(objFind).header("access-control-allow-headers",
				"DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range,Access-Token,Authorization")
				.header("authorization", "Basic ZWRzc29udzExQGdtYWlsLmNvbTp0ZWNoMjA4MQ==")
				.header("access-token", autentication.getAccess_token())
				// .header("access-token",
				// "O62AjLdEI/aYU450Y2z7pPJmNBpap7wqe9KCKoNz3dLTHFz8o7q917MqlYfAJl3LtPHuSutvC4wTwgnDBBl/SQ==--HN/OWBlOW9kK1IKXM+Dw8g==--6Pbbam5VueoWsrgRKkyTmQ==")
				// .header("email", email)
				// .header("password", password)
				.header("cache-control", "no-cache").header("postman-token", "9f127d97-6815-3fe9-e4d2-eff406e5e17c")
				.asString();

		return doBuilDopAberta(response);

	}

	private static Screen doBuildScreen(HttpResponse<String> response) throws IOException {

		Screen screen = new Gson().fromJson(response.getBody(), Screen.class);

		Options listOpcoes = null;

		List<Series> listaSeireTMP = new ArrayList<Series>();

		List<StockWritter> listaStockWritter = new ArrayList<StockWritter>();

		LinkedTreeMap objSeries = new Gson().fromJson(screen.getListSeries().toString(), LinkedTreeMap.class);

		//System.out.println(objSeries);

		Iterator iterator = ((Map) objSeries).entrySet().iterator();

		while (iterator.hasNext()) {

			Map.Entry entry = (Map.Entry) iterator.next();
			//System.out.println(entry.getKey() + "->" + entry.getValue());

			Series objSerie = new Gson().fromJson(entry.getValue().toString(), Series.class);

			Iterator iteratorOp = ((Map) objSerie.getListOptionOBJs()).entrySet().iterator();

			while (iteratorOp.hasNext()) {

				Map.Entry entryOp = (Map.Entry) iteratorOp.next();

				Options opSeries = new Gson().fromJson(entryOp.getValue().toString(), Options.class);

				//System.out.println(entryOp.getKey() + "->" + entryOp.getValue());

				StockWritter sW = new StockWritter();

				sW.setSerie(objSerie.getName());
				sW.setOpcao(entryOp.getKey().toString());
				sW.setStrike(opSeries.getStrike());
				sW.setUltimo(opSeries.getClose());
				sW.setBid(opSeries.getBid());
				sW.setAsk(opSeries.getAsk());

				//System.out.println("Serie : " + sW.getSerie());
				//System.out.println("Opcao : " + sW.getOpcao());
				//System.out.println("Strike : " + sW.getStrike());
				//System.out.println("Ultimo : " + sW.getUltimo());
				//System.out.println("Bid : " + sW.getBid());
				//System.out.println("Ask : " + sW.getAsk());

				listaStockWritter.add(sW);

				screen.getListaStockWritter().add(sW);

			}

		}

		return screen;

	}

	public static void createWorkbookEverHedge(List<StockWritter> listStockWritter, String dir) throws IOException {

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("NovaEstrategiaAnaliseEverHedge");

		sheet.setDefaultColumnWidth(15);
		sheet.setDefaultRowHeight((short) 400);

		int rownum = 0;
		int cellnum = 1;
		Cell cell;
		Row row;

		// Configurando estilos de células (Cores, alinhamento, formatação, etc..)
		HSSFDataFormat numberFormat = workbook.createDataFormat();

		CellStyle headerStyle = workbook.createCellStyle();
		headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
		headerStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		CellStyle textStyle = workbook.createCellStyle();
		textStyle.setAlignment(CellStyle.ALIGN_LEFT);
		textStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

		CellStyle numberStyle = workbook.createCellStyle();

		numberStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

//			
//			private String serie;
//			private String opcao;
//			private String strike;
//			private String ultimo;
//			private String bid;
//			private String ask;
//			
		// Configurando Header
		row = sheet.createRow(rownum++);
		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Serie");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Opcao");

//				cell = row.createCell(cellnum++);
//				cell.setCellStyle(headerStyle);
//				cell.setCellValue("series_name");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Strike");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("Ultimo");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("bid");

		cell = row.createCell(cellnum++);
		cell.setCellStyle(headerStyle);
		cell.setCellValue("ask");

		// Adicionando os dados dos produtos na planilha
		for (StockWritter stockWritter : listStockWritter) {

			row = sheet.createRow(rownum++);
			cellnum = 1;

			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyle);
			cell.setCellValue(stockWritter.getSerie());
			numeroDeExtrategias++;

			// row = sheet.createRow(rownum++);
			// cellnum = 2;

			cell = row.createCell(cellnum++);
			cell.setCellStyle(textStyle);
			cell.setCellValue(stockWritter.getOpcao());

//						  cell = row.createCell(cellnum++);
//						  cell.setCellStyle(textStyle);
//						  cell.setCellValue(op.getSeries_name());

			cell = row.createCell(cellnum++);
			cell.setCellStyle(numberStyle);
			cell.setCellType(cellnum);

			cell.setCellValue(stockWritter.getStrike());

			cell = row.createCell(cellnum++);
			cell.setCellStyle(numberStyle);
			cell.setCellValue(stockWritter.getUltimo());

			cell = row.createCell(cellnum++);
			cell.setCellStyle(numberStyle);
			cell.setCellValue(stockWritter.getBid());

			cell = row.createCell(cellnum++);
			cell.setCellStyle(numberStyle);
			cell.setCellValue(stockWritter.getAsk());

		}

		try {
			FileOutputStream out;

			if ((dir != null)) {
				// Escrevendo o arquivo em disco
				out = new FileOutputStream(dir + ".xls");
				
				
			} else {
				
				JFileChooser fc = new JFileChooser();

				int returnVal = fc.showSaveDialog(new JFrame());

				// Escrevendo o arquivo em disco
				out = new FileOutputStream(fc.getSelectedFile() + ".xls");


			}

			JOptionPane.showConfirmDialog(null, numeroDeExtrategias + " Artefatos exportada com com Sucesso!!", "",
					JOptionPane.WARNING_MESSAGE);

			//System.out.println("Success!!");

			numeroDeExtrategias = 0;

			workbook.write(out);
			out.close();
			workbook.close();
			
		//	System.exit(0);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		

	}

	private static List<OpAberta> doBuilDopAberta(HttpResponse<String> response) {

		OpAberta[] obj = new Gson().fromJson(response.getBody(), OpAberta[].class);

		List<OpAberta> listaOperacoesAbertas = new ArrayList<OpAberta>();

		for (OpAberta obA : obj) {
			// ArrayList<OpAberta> legAberta = new ArrayList<OpAberta>();
			Iterator iterator = ((Map) obA.getLegsAbertas()).entrySet().iterator();

			LegAberta[] legAberta = null;

			while (iterator.hasNext()) {
				Map.Entry entry = (Map.Entry) iterator.next();

				if (entry.getKey().equals("in")) {

//    		        	System.out.print( "%%%%% In %%%%% \n" );
//        		        System.out.print(entry.getValue() +  "%%%%% \n" );
//        		        System.out.print( "%%%%% In %%%%% \n" );

					legAberta = new Gson().fromJson(
							entry.getValue().toString().trim().replaceAll("maturity-type=}", "maturity-type=papel}"),
							LegAberta[].class);

					// listaOperacoesAbertas.get(0).getListLegs().add(null)

				}

			}

			//System.out.println("+++++++ Operacao Aberta ++++++++++ \n");
			//System.out.println(obA.getName());

			for (LegAberta leg : legAberta) {
				//System.out.print("Opcao : " + leg.getSymbol());
				obA.getListLegs().add(leg);
			}

			listaOperacoesAbertas.add(obA);

		}

		return listaOperacoesAbertas;
	}

	public void getPage(URL url, File file) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

		BufferedWriter out = new BufferedWriter(new FileWriter(file));

		String inputLine;

		while ((inputLine = in.readLine()) != null) {

			// Imprime página no console
			//System.out.println(inputLine);

			// Grava pagina no arquivo
			out.write(inputLine);
			out.newLine();
		}

		out.flush();
		in.close();
		out.close();
	}

	/// unica que deu certo
//   curl -i -X POST https://api.oplab.com.br/v2/users/authenticate \
//	   -H 'Content-Type: application/json' \
//	     -d $'{
//	   "postId": 101, 
//       "email": "edsonw11@gmail.com",
//       "password": "tech2081" }' 

//
// curl -i -X POST https://api.oplab.com.br/v2/users/authenticate \ 
//	 + "  -H "'Content-Type: application/json'" \ ";
//	     -d $'{
//	   "postId": 101, 
//    "email": "edsonw11@gmail.com",
//    "password": "tech2081" }' 

	// {"name":"edson batista da
	// silva","id":49667,"preferences":{"interest-rate-type":"SELIC","interest-rate-value":0,"brokerage-fee":0,"order-amount":1000,"notify-on-maturity-date-by-email":true,"notify-on-strategy-change-by-email":true,"notify-on-maturity-date-by-push":true,"notify-on-strategy-change-by-push":true,"simulate-price-strategy":"BID_ASK","simulate-with-brokerage-and-fees":false,"interest_rate_type":"SELIC","interest_rate_value":1.8999411926388765,"broker":"OTHER","brokerage_fee":0.8,"order_amount":1000,"simulate_price_strategy":"LAST","position_price_strategy":["BOOK","LAST","THEORETICAL"],"simulate_with_brokerage_and_fees":true,"custom_perspective":["bid","ask"],"default_web_app_version":null,"tinted_moneyness":true},"email":"edsonw11@gmail.com","last-login":"2021-07-01T11:39:02.443-03:00","category":"MAX","permissions":"9d30dba575402d144d4861c094cf8441883f426f80888b6fb5f6cba780835665","access-token":"4L+edm2tNMbmvGzhTx7ve7eNdQknDpYzqnC1altHZ7UDOrCUu1KhcHUExoVHdVLYJ2QjklWXTjqtu5WCVhV+vQ==--xjVBdd6iaqMC3zCWYesCnQ==--uyLYNPXsADsm4XocyahDIQ==","data-access":"REAL_TIME","display-name":"edson
	// batista da
	// silva","avatar":"https://www.gravatar.com/avatar/7b455962a69cffa7e2abdcece73dfb2c?d=mm","versions":{"WEB_PWA_APP":"2.19.5"},"days-to-expiration":null,"default-portfolio":60067,"minimum-version":2,"datafeed-access-token":"2EL7yvKFmH3r3IPYRNNnyU2OyoWDeUMNydj5NtI4eestz4TO9tQ+UFTbCqi2LVJsTQYGBKVHUDClVrig7X0EJy7VrwGSz9ApWBxRoNebOBA=--6JCGB/pFEo6TDid/0z2t9A==--SOGLvo03cr0QkxtIDf6oog==","endpoints":["wss://datafeed05.oplab.com.br"],"servers":[{"url":"wss://datafeed05.oplab.com.br","level":1}]}

}
